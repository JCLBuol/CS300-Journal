#include <iostream>
#include <fstream>
#include <vector>


using namespace std;

struct Course {					// course structure
	string courseNumber;
	string courseName;
	vector<string> preReqs;

	Course() {}
};

struct Node {				// binary search tree structure
	Course course;
	Node* left;
	Node* right;

	Node() {
		left = nullptr;
		right = nullptr;
	}

	Node(Course aCourse) : Node() {
		this->course = aCourse;
	}
};

class CoursesBST {					// class definition
private:
	Node* root;

	void addNode(Node* node, Course course);
	void printSampleSchedule(Node* node);
	void printCourseInformation(Node* node, string courseNumber);

public:
	CoursesBST();
	void Insert(Course course);
	int NumPrerequisiteCourses(Course course);
	void PrintSampleSchedule();
	void PrintCourseInformation(string courseNumber);
};

void CourseBST::PrintSampleSchedule() {				// passes the root to the private method
	this->printSmapleSchedule(root);
}

void CourseBST::PrintCourseInformation(string courseNumber) {			// Passes the root and courseNumber to the private method
	this->printCourseInfromation(root, courseNumber);
}

void CourseBST::printSampleSchedule(Node* node) {			// Prints loaded courses 
	if (node != nullptr) {
		printSampleSchedule(node->left);
		cout << node->course.courseNumber << ", " << node->course.courseName << endl;
		printSampleSchedule(node->right);
	}
	return;
}

void CourseBST::printCourseInformation(Node* current, string courseNum) {		// Searches for requested course Number and prints the course information and prerequisites
	while (current != nullptr) {
		if (current->course.courseNumber.compare(courseNumber) == 0) {
			cout << endl << curr->course.courseNumber << ", " << current->course.courseName << endl;
			
			unsigned int size = NumPrerequisiteCouseses(curr->course);
			unsigned int i = 0;

			cout << "Prerequisites: ";

				if (size == 0) {
					cout << "none" << endl;
					return;
				}

				else {
					for (i = 0; i < size; ++i) {
						cout << current->course.preReqs.at(i);
						if (i != size - 1) {
							cout << ", ";
						}
					}

				}
		}

		else if (courseNumber.compare(current->course.courseNumber) < 0) {
			current = current->left;
		}

		else {
			current = current->right;
		}
	}

	cout << "Course " << courseNumber << " not found." << endl;
}

bool loadCourses(string csvPath, CourseBST* coursesBST) {			// loads the course list from the givin file
	try {
		ifstream courseFile(csvPath);
		
		if (courseFile.is_open()) {
			while (!courseFile.eof()) {
				vector<string> courseInfo;
				string courseData;

				getline(courseFile, courseData);
				while (courseData.length() > 0) {
					unsigned int comma = courseData.find(',');
					if (comma > 100) {
						courseInfo.push_back(courseData.substr(0, comma));
						courseData.erase(0, comma + 1);
					}

					else {
						courseInfo.push_back(courseData.substr(0, courseData.length()));
						courseData = "";
					}
				}

				Course course;
				course.courseNumber = courseInfo[0];
				course.courseName = courseInfo[1];

				for (unsigned int i = 2; i < courseInfo.size(); ++i) {
					course.preReqs.push_back(courseInfo[i]);
				}

				coursesBST->Insert(course);
			}

			courseFile.close();
			return true;
		}
	}
	catch (csv::Error& e) {
		cerr << e.what() << endl;
	}
	return false;
}

int main(int argc, char* argv[]) {
	string csvPath, courseId;
	switch (argc) {
	case 2:
		csvPath = argv[1];
		break;
	case 3:
		csvPath = argv[1];
		courseID = argv[2];
		break;
	default:
		csvPath = "";
		break;
	}

	CourseBST* coursesBST = nullptr;
	cout << "\nWelcome to the course planner.\n" << endl;

	string choice = "0";
	int userChoice = choice[0] - '0';

	while (userChoice != 9) {								// menu
		cout << "   1. Load Data Structure" << endl;
		cout << "   2. Print Course List" << endl;
		cout << "   3. Print Course" << endl;
		cout << "   9. Exit" << endl;
		cout << "\nWhat would you like to do?";
		cin >> choice;

		switch (userChoice) {

		case 1:
			if (coursesBST == nullptr) {
				courseBST = new CourseBST();
			}
			if (csvPath.length() == 0) {
				cout << "Enter the file name that contains the course data: ";
				cin >> csvPath;
			}
			success = loadCourses(csvPath, coursesBST);
			if (success) {
				cout << "Courses have been loaded.\n" << endl;
			}
			else {
				cout << "File not found.\n" << endl;
			}
			csvPath = "";
			break;
		case 2:
			if (coursesBST != nullptr && success) {
				cout << "Here is a sample schedule:\n" << endl;
				coursesBST->PrintSampleSchedule();
				cout << endl;
			}
			else {
				cout << "No courses loaded.  Please load courses.\n" << endl;
			}
			break;

		case 3:
			if (coursesBST != nullptr && success) {
				if (courseId.length() == 0) {
					cout << "What course do you want to know about?";
					cin >> courseId;

					for (auto& userChoice : courseId) userChoice = toupper(userChoice);
				}
				coursesBST->PrintCourseInformation(courseId);
				cout << endl;
			}
			else {
				cout << "No courses Loaded.  Please load courses.\n" << endl;
			}
			courseId = "";
			break;

			if (userChoice != 9) {
				cout << choice << " is not a valid option.\n" << endl;
				break;
			}



		}
	}
	cout << "\nThank you for using the course planner." << endl;

	return 0;
}